package com.example.BIS.repo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.BIS.entity.Books;

public interface BooksRepo extends JpaRepository<Books, Long> {

	List<Books> findByLang(String language);

	List<Books> findByGenre(String genre);

}
