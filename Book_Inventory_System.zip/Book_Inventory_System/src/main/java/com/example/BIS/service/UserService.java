package com.example.BIS.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.BIS.entity.User;
import com.example.BIS.exception.ResourceNotFoundException;
import com.example.BIS.repo.UserRepo;

@Service
public class UserService {
	 @Autowired
	    private UserRepo ur;

	    //For adding a user's data
	    public User saveData(User user) {
	        return ur.save(user);
	    }
	    
	    //To update user's data by ID
	    public User updateData(Long user_id, User user) {
	        // Check if the user exists
	        Optional<User> existingUserOptional = ur.findById(user_id);

	        if (existingUserOptional.isPresent()) {
	            // Get the existing user
	            User existingUser = existingUserOptional.get();  

	            //Update the existing fields with new data
	            existingUser.setStatus(user.getStatus());
	            existingUser.setDate_the_book_was_returned(user.getDate_the_book_was_returned());
	            
	            // Save the updated data back to the repository
	            return ur.save(existingUser);
	        } else {
	            // Return null if the data is not found
	            return null;
	        }
	    }

	    // Get all users' data
	    public List<User> getAllUsers() {
	        return ur.findAll();
	    }

	    // Get user by ID
	    public User getUserById(Long user_id) {
	        Optional<User> data = ur.findById(user_id);
	        if (data.isPresent()) {
	            return data.get();
	        } else {
	            throw new ResourceNotFoundException("Sorry! We did not find any user with id: " + user_id);
	        }
	    }
	    
	    // Get data of users based on status of book
	    public List<User> getUserbyStat(String status) {
	        return ur.findByStatus(status);
	    }

	    // Delete user's data by ID
	    public void deleteUser(Long user_id) {
	        Optional<User> data = ur.findById(user_id);
	        if (data.isPresent()) {
	            ur.deleteById(user_id);
	        } else {
	            throw new ResourceNotFoundException("Sorry! We did not find any supplier with id: " + user_id);
	        }
	    }
	}
