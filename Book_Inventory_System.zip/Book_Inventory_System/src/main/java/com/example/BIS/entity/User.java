package com.example.BIS.entity;

import java.time.LocalDate;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

@Data
@Entity
@Table(name="User data")
@Getter
@Setter
public class User {
	@Id  //Indicates the primary key
	@GeneratedValue(strategy=GenerationType.IDENTITY)   //enables auto-increment
	private Long user_id; 
	
	@NotNull(message="Enter the name of the user")
	@Size(min=2,max=30,message="The name must be between 2 to 30 characters")
	private String name;
	
	@NotNull(message="Enter the name of book borrowed/purchased")
	@Size(min=2,max=30,message="The name must be between 2 to 30 characters")
	private String book_name;
	
	@NotNull(message="Enter the status of book")
	@Size(min=8, max=9, message="Enter proper data")
	private String status;
	
	@NotNull(message="Enter the proper date")
	private LocalDate date_of_borrowing_or_purchasing_book;
	
	@NotNull(message="Enter the proper date")
	private LocalDate estimated_date_of_returning_book;
	
	private LocalDate date_the_book_was_returned;
	
}
