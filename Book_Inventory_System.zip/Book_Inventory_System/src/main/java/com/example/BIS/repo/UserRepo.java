package com.example.BIS.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.BIS.entity.User;

public interface UserRepo extends JpaRepository<User, Long> {

	List<User> findByStatus(String status);

}
