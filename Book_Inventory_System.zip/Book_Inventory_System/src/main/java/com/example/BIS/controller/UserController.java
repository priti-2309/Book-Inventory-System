package com.example.BIS.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.BIS.entity.User;
import com.example.BIS.service.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserService userservice;

    //Add a user record
    @PostMapping
    public ResponseEntity<User> addData(@Valid @RequestBody User user, BindingResult result) {
        // If there are validation errors
        if (result.hasErrors()) {
            return new ResponseEntity<User>(HttpStatus.BAD_REQUEST);
        }
        
        // If no validation errors, save the record
        User savedData = userservice.saveData(user);
        return new ResponseEntity<User>(savedData, HttpStatus.OK);
    }

    // Update user record by ID
    @PatchMapping("update/{id}")
    public ResponseEntity<User> updateQuantity(@PathVariable("id") Long user_id, @RequestBody User user) {
        User updatedData = userservice.updateData(user_id, user);

        if (updatedData == null) {
            // If user not found, return 404 Not Found
            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<User>(updatedData, HttpStatus.OK);
    }

    // Get all user records
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> data = userservice.getAllUsers();
        return new ResponseEntity<>(data, HttpStatus.OK);
    }

    // Get a user record by ID
    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable("id") Long user_id) {
        User data = userservice.getUserById(user_id);
        return new ResponseEntity<>(data, HttpStatus.OK);
    }
    
 // Get user by book status
    @GetMapping("status/{book_status}")  
    public ResponseEntity<List<User>> getUserbyStatus(@PathVariable String status) {
        List<User> data = userservice.getUserbyStat(status);
        if (data.isEmpty()) {
            return ResponseEntity.noContent().build();  // Return 204 No Content if no user found
        }
        return ResponseEntity.ok(data);  // Return user record with 200 OK
    }

    // Delete any user record by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBook(@PathVariable("id") Long user_id) {
        userservice.deleteUser(user_id);
        return new ResponseEntity<>("User record deleted successfully", HttpStatus.NO_CONTENT);
    }
}