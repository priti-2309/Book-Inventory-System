package com.example.BIS.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.BIS.entity.Supplier;
import com.example.BIS.service.SupplierService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/supplier")
public class SupplierController {

    @Autowired
    private SupplierService supplierservice;

    //Add a supplier's data
    @PostMapping
    public ResponseEntity<Supplier> addSupplier(@Valid @RequestBody Supplier supplier, BindingResult result) {
        // If there are validation errors
        if (result.hasErrors()) {
            return new ResponseEntity<Supplier>(HttpStatus.BAD_REQUEST);
        }
        
        // If no validation errors, save the data
        Supplier savedData = supplierservice.saveData(supplier);   
        return new ResponseEntity<Supplier>(savedData, HttpStatus.OK);
    }


    // Update supplier's data by ID
    @PutMapping("/{id}")
    public ResponseEntity<Supplier> updateData(@PathVariable("id") Long s_id, @RequestBody Supplier supplier) {
        Supplier updatedData = supplierservice.updateData(s_id, supplier);

        if (updatedData == null) {
            // If supplier not found, return 404 Not Found
            return new ResponseEntity<Supplier>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Supplier>(updatedData, HttpStatus.OK);
    }

    // Get all suppliers' data
    @GetMapping
    public ResponseEntity<List<Supplier>> getAllSuppliers() {
        List<Supplier> data = supplierservice.getAllSuppliers();
        return new ResponseEntity<>(data, HttpStatus.OK);
    }

    // Get a supplier by ID
    @GetMapping("/{id}")
    public ResponseEntity<Supplier> getBookById(@PathVariable("id") Long s_id) {
        Supplier data = supplierservice.getSupplierById(s_id);
        return new ResponseEntity<>(data, HttpStatus.OK);
    }
    
 // Get suppliers by location
    @GetMapping("location/{location}")
    public ResponseEntity<List<Supplier>> getSuppliersByLocation(@PathVariable String location) {
        List<Supplier> data = supplierservice.getSuppliersByLocation(location);
        if (data.isEmpty()) {
            return ResponseEntity.noContent().build();  // Return 204 No Content if no data found
        }
        return ResponseEntity.ok(data);  // Return data with 200 OK
    }
    
    // Delete supplier's data by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteSupplier(@PathVariable("id") Long s_id) {
        supplierservice.deleteSupplier(s_id);
        return new ResponseEntity<>("Data deleted successfully", HttpStatus.NO_CONTENT);
    }
}
