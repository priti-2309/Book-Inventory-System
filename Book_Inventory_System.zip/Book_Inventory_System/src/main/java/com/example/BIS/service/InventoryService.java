package com.example.BIS.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.BIS.entity.Inventory;
import com.example.BIS.exception.ResourceNotFoundException;
import com.example.BIS.repo.InventoryRepo;

@Service
public class InventoryService {

    @Autowired
    private InventoryRepo ir;

    //For adding a book details in inventory
    public Inventory saveInventory(Inventory inventory) {
        return ir.save(inventory);
    }
    
    //To update book quantity by ID
    public Inventory updateQuantity(Long book_id, Inventory inventory) {
        // Check if the book exists
        Optional<Inventory> existingBooksOptional = ir.findById(book_id);

        if (existingBooksOptional.isPresent()) {
            // Get the existing book
            Inventory existingBooks = existingBooksOptional.get();

            //Update the book quantity
            existingBooks.setQuantity(inventory.getQuantity());

            // Save the updated book data back to the repository
            return ir.save(existingBooks);
        } else {
            // Return null if the book is not found
            return null;
        }
    }

    // Get all books in inventory
    public List<Inventory> getAllBooks() {
        return ir.findAll();
    }

    // Get books in inventory by ID
    public Inventory getBooksById(Long book_id) {
        Optional<Inventory> books = ir.findById(book_id);
        if (books.isPresent()) {
            return books.get();
        } else {
            throw new ResourceNotFoundException("Sorry! We did not find the book with id: " + book_id);
        }
    }
    
    // Get books in inventory by their location
    public List<Inventory> getBooksByLocation(String location) {
        return ir.findByLocation(location);
    }
 
    // Delete book from inventory by ID
    public void deleteBooks(Long book_id) {
        Optional<Inventory> books = ir.findById(book_id);
        if (books.isPresent()) {
            ir.deleteById(book_id);
        } else {
            throw new ResourceNotFoundException("Sorry! We did not find book with id: " + book_id);
        }
    }
}