package com.example.BIS.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

@Data
@Entity
@Table(name="Inventory")
@Getter
@Setter
public class Inventory {
	@Id  //Indicates the primary key
	@GeneratedValue(strategy=GenerationType.IDENTITY)   //enables auto-increment
	private Long book_id; 
	
	@NotNull(message="Enter the title of the book")
	@Size(min=2,max=30,message="The title must be between 2 to 30 characters")
	private String title;
	
	@NotNull(message="Enter the quantity of book")
	@Min(value=1)
	@Max(value=100)
	private int quantity;
	
	@NotNull(message="Enter the location of the book")
	@Size(min=7, max=7, message="Enter proper data")
	private String location;
	
	@Column(length=10,nullable=false)
    @NotNull(message="Enter the price of the book")
    private Double price;
	
	

}
