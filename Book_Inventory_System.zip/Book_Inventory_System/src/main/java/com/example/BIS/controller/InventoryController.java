package com.example.BIS.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.BIS.entity.Inventory;
import com.example.BIS.service.InventoryService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {

    @Autowired
    private InventoryService invservice;

    //Add a book to inventory
    @PostMapping
    public ResponseEntity<Inventory> addBook(@Valid @RequestBody Inventory inventory, BindingResult result) {
        // If there are validation errors
        if (result.hasErrors()) {
            return new ResponseEntity<Inventory>(HttpStatus.BAD_REQUEST);
        }
        
        // If no validation errors, save the books
        Inventory savedBook = invservice.saveInventory(inventory);
        return new ResponseEntity<Inventory>(savedBook, HttpStatus.OK);
    }

    // Update book quantity by ID
    @PatchMapping("quantity/{id}")
    public ResponseEntity<Inventory> updateQuantity(@PathVariable("id") Long book_id, @RequestBody Inventory inventory) {
        Inventory updatedBook = invservice.updateQuantity(book_id, inventory);

        if (updatedBook == null) {
            // If book not found, return 404 Not Found
            return new ResponseEntity<Inventory>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Inventory>(updatedBook, HttpStatus.OK);
    }

    // Get all books from inventory
    @GetMapping
    public ResponseEntity<List<Inventory>> getAllBooks() {
        List<Inventory> books = invservice.getAllBooks();
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

    // Get a book by ID
    @GetMapping("/{id}")
    public ResponseEntity<Inventory> getBookById(@PathVariable("id") Long book_id) {
        Inventory books = invservice.getBooksById(book_id);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
    
 // Get books from Inventory by their Location
    @GetMapping("location/{location}")      
    public ResponseEntity<List<Inventory>> getBooksByLocation(@PathVariable String location) {
        List<Inventory> books = invservice.getBooksByLocation(location);
        if (books.isEmpty()) {
            return ResponseEntity.noContent().build();  // Return 204 No Content if no books found
        }
        return ResponseEntity.ok(books);  // Return books with 200 OK
    }

    // Delete books from inventory by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBook(@PathVariable("id") Long book_id) {
        invservice.deleteBooks(book_id);
        return new ResponseEntity<>("Book deleted successfully", HttpStatus.NO_CONTENT);
    }
}