package com.example.BIS.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Data   //Adds LOMBOK property
@Entity   //Makes the POJO as JPA Entity
@Table(name="Books")  //Specifies name of table
@Getter   //Adding Getters
@Setter   //Adding Setters
public class Books {
	@Id  //Indicates the primary key
	@GeneratedValue(strategy=GenerationType.IDENTITY)   //enables auto-increment
	private Long book_id; 
	
	@NotNull(message="Enter the title of the book")
	@Size(min=2,max=30,message="The title must be between 2 to 30 characters")
	private String title;
	
	@NotNull(message="Enter the author of the book")
	@Size(min=2,max=20,message="The name must be between 2 to 20 characters")
	private String author;
	
	@NotNull(message="Enter the ISBN")
	@Size(min=13, max=13, message="ISBN must be of 13 digits")
	@Pattern(regexp= "^978\\d{10}$", message = "Invalid ISBN. It must be 13 digits and start with 978")
	private String isbn;
	
	@NotNull(message="Enter the language of the book")
	private String lang;
	
	@NotNull(message="Enter the year of the book's publishment")
	@Min(value=1900)
	@Max(value=2025)
	private int year;
	
	@NotNull(message="Enter the genre of the book")
	@Size(min=2, max=20, message="Enter proper data")
	private String genre;
		
}
