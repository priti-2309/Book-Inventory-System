package com.example.BIS.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.BIS.entity.Supplier;
import com.example.BIS.exception.ResourceNotFoundException;
import com.example.BIS.repo.SupplierRepo;

@Service
public class SupplierService {
	 @Autowired
	    private SupplierRepo sr;

	    //For adding a supplier's data
	    public Supplier saveData(Supplier supplier) {
	        return sr.save(supplier);
	    }
	    
	    //To update supplier's data by ID
	    public Supplier updateData(Long s_id, Supplier supplier) {
	        // Check if the supplier exists
	        Optional<Supplier> existingSupplierOptional = sr.findById(s_id);

	        if (existingSupplierOptional.isPresent()) {
	            // Get the existing supplier
	            Supplier existingSupplier = existingSupplierOptional.get();

	            //Update the existing fields with new data
	            existingSupplier.setName(supplier.getName());
	            existingSupplier.setEmail(supplier.getEmail());
	            existingSupplier.setPhone(supplier.getPhone());
	            existingSupplier.setLocation(supplier.getLocation());
	          
	            // Save the updated data back to the repository
	            return sr.save(existingSupplier);
	        } else {
	            // Return null if the supplier data is not found
	            return null;
	        }
	    }

	    // Get all supplier's data
	    public List<Supplier> getAllSuppliers() {
	        return sr.findAll();
	    }

	    // Get suppliers by ID
	    public Supplier getSupplierById(Long s_id) {
	        Optional<Supplier> data = sr.findById(s_id);
	        if (data.isPresent()) {
	            return data.get();
	        } else {
	            throw new ResourceNotFoundException("Sorry! We did not find any supplier with id: " + s_id);
	        }
	    }
	    
	    // Get data of Suppliers belonging to specific location
	    public List<Supplier> getSuppliersByLocation(String location) {
	        return sr.findByLocation(location);
	    }

	    // Delete supplier's data by ID
	    public void deleteSupplier(Long s_id) {
	        Optional<Supplier> data = sr.findById(s_id);
	        if (data.isPresent()) {
	            sr.deleteById(s_id);
	        } else {
	            throw new ResourceNotFoundException("Sorry! We did not find any supplier with id: " + s_id);
	        }
	    }
	}
