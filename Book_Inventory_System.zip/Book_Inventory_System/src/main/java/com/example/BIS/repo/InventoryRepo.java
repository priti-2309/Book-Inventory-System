package com.example.BIS.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.BIS.entity.Inventory;

public interface InventoryRepo extends JpaRepository<Inventory, Long> {
    //To get books by their location
	List<Inventory> findByLocation(String location);

}
