package com.example.BIS.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Data
@Entity
@Table(name="Supplier Data")
@Getter
@Setter
public class Supplier {
	@Id  //Indicating primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY)  //For auto-increment
    private Long s_id;
    
    @Column(length=20,nullable=false)
    @NotNull(message="Name is required")
    @Size(min=2,max=30)
    private String name;
    
    @Column(length=30,nullable=false,unique=true)
    @NotNull(message="Email is required")
    @Email(message="Email should be valid")
    private String email;
    
    @Column(length=10,nullable=false,unique=true)
    @NotNull(message="Phone number is required")
    @Pattern(regexp="[6789]{1}[0-9]{9}",message="Enter proper phone number")
    private String phone;
    
    @NotNull(message="Location is required")
	@Size(min=5, max=20, message="Enter proper data")
	private String location;
}
