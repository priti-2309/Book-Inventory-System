package com.example.BIS.service;

import com.example.BIS.entity.Books;
import com.example.BIS.exception.ResourceNotFoundException;
import com.example.BIS.repo.BooksRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class BookService {

    @Autowired
    private BooksRepo br;

    //For adding a book
    public Books saveBook(Books books) {
        return br.save(books);
    }
    
    //To update book information by ID
    public Books updateBook(Long book_id, Books books) {
        // Check if the book exists
        Optional<Books> existingBooksOptional = br.findById(book_id);

        if (existingBooksOptional.isPresent()) {
            // Get the existing book
            Books existingBooks = existingBooksOptional.get();

            //Update the existing book fields with new data
            existingBooks.setTitle(books.getTitle());
            existingBooks.setIsbn(books.getIsbn());
            existingBooks.setLang(books.getLang());
            existingBooks.setYear(books.getYear());
            existingBooks.setGenre(books.getGenre());
      
            // Save the updated book data back to the repository
            return br.save(existingBooks);
        } else {
            // Return null if the book is not found
            return null;
        }
    }

    // Get all books
    public List<Books> getAllBooks() {
        return br.findAll();
    }

    // Get books by ID
    public Books getBooksById(Long book_id) {
        Optional<Books> books = br.findById(book_id);
        if (books.isPresent()) {
            return books.get();
        } else {
            throw new ResourceNotFoundException("Sorry! We did not find the book with id: " + book_id);
        }
    }
    
    // Get books by Language
    public List<Books> getBooksByLang(String lang) {
        return br.findByLang(lang);
    }
    
 // Get books by Year of publication
   public List<Books> getBooksbyGenre(String genre){
	   return br.findByGenre(genre);
   }

    // Delete book by ID
    public void deleteBooks(Long book_id) {
        Optional<Books> books = br.findById(book_id);
        if (books.isPresent()) {
            br.deleteById(book_id);
        } else {
            throw new ResourceNotFoundException("Sorry! We did not find book with id: " + book_id);
        }
    }
}
