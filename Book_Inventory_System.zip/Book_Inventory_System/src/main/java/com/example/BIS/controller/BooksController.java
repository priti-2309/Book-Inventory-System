package com.example.BIS.controller;

import com.example.BIS.entity.Books;
import com.example.BIS.service.BookService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BooksController {

    @Autowired
    private BookService bookservice;

    //Add a book
    @PostMapping
    public ResponseEntity<Books> addBook(@Valid @RequestBody Books books, BindingResult result) {
        // If there are validation errors
        if (result.hasErrors()) {
            return new ResponseEntity<Books>(HttpStatus.BAD_REQUEST);
        }
        
        // If no validation errors, save the book
        Books savedBook = bookservice.saveBook(books);
        return new ResponseEntity<Books>(savedBook, HttpStatus.OK);
    }


    // Update book by ID
    @PutMapping("/{id}")
    public ResponseEntity<Books> updateBooks(@PathVariable("id") Long book_id, @RequestBody Books books) {
        Books updatedBook = bookservice.updateBook(book_id, books);

        if (updatedBook == null) {
            // If book not found, return 404 Not Found
            return new ResponseEntity<Books>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Books>(updatedBook, HttpStatus.OK);
    }

    // Get all books
    @GetMapping
    public ResponseEntity<List<Books>> getAllBooks() {
        List<Books> books = bookservice.getAllBooks();
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

    // Get a book by ID
    @GetMapping("/{id}")
    public ResponseEntity<Books> getBookById(@PathVariable("id") Long book_id) {
        Books books = bookservice.getBooksById(book_id);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
    
 // Get books by Language
    @GetMapping("language/{lang}")
    public ResponseEntity<List<Books>> getBooksByLang(@PathVariable String lang) {
        List<Books> books = bookservice.getBooksByLang(lang);
        if (books.isEmpty()) {
            return ResponseEntity.noContent().build();  // Return 204 No Content if no books found
        }
        return ResponseEntity.ok(books);  // Return books with 200 OK
    }
    
 // Get books by Genre
    @GetMapping("genre/{genre}")
    public ResponseEntity<List<Books>> getBooksByGenre(@PathVariable String genre) {
        List<Books> books = bookservice.getBooksbyGenre(genre);
        if (books.isEmpty()) {
            return ResponseEntity.noContent().build();  // Return 204 No Content if no books found
        }
        return ResponseEntity.ok(books);  // Return books with 200 OK
    }

    // Delete Book by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBook(@PathVariable("id") Long book_id) {
        bookservice.deleteBooks(book_id);
        return new ResponseEntity<>("Book deleted successfully", HttpStatus.NO_CONTENT);
    }
}
