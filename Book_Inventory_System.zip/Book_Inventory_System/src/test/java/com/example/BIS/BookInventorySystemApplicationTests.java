package com.example.BIS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookInventorySystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
